# COMPREHENSIVE PAPER VERIFICATION TOOL
## User Guide

**Version:** 1.0  
**Created:** December 2025  
**For:** Professor Nikolaos Lavidas

---

## 📋 **WHAT THIS TOOL DOES**

This tool provides **complete verification** of academic papers, including:

### **Phase 1: Citation Verification**
✅ Extracts ALL citations from Word documents  
✅ Identifies unique vs. duplicate citations  
✅ Lists all works cited in the paper  

### **Phase 2: Contradiction Analysis** ⭐ 
✅ **Temporal contradictions** - Wrong years, impossible dates  
✅ **Attribution contradictions** - Same work cited different ways  
✅ **Thematic contradictions** - References don't match paper topic  

### **Phase 3: Document Marking**
✅ Marks issues in **BOLD GREEN** (severe) or **ORANGE** (moderate)  
✅ Adds detailed corrections page to document  
✅ Makes errors easy to find and fix  

### **Phase 4: Comprehensive Reporting**
✅ Generates detailed markdown reports  
✅ Lists all contradictions with fixes  
✅ Provides statistics and summary  
✅ Cross-paper analysis for multiple papers  

---

## 🚀 **QUICK START**

### **Installation**

```bash
# 1. Ensure you have Python 3.7+
python3 --version

# 2. Install required package
pip install python-docx

# 3. Download the tool folder
# Extract to your preferred location
```

### **Basic Usage**

```bash
# Navigate to tool directory
cd paper_verification_tool

# Run interactive mode
python3 verify_paper.py

# Or verify single paper directly
python3 verify_paper.py your_paper.docx

# Or verify multiple papers
python3 verify_paper.py paper1.docx paper2.docx paper3.docx
```

---

## 📖 **DETAILED USAGE**

### **Method 1: Interactive Mode** (Easiest)

```bash
python3 verify_paper.py
```

Follow the prompts:
1. Select mode (single paper / multiple papers)
2. Enter paper path(s)
3. Describe paper topic
4. Choose output directory
5. Done!

**Example Session:**
```
COMPREHENSIVE PAPER VERIFICATION TOOL
Citation Verification + Contradiction Analysis
================================================================================

🔍 VERIFICATION MODE:
   1. Single paper
   2. Multiple papers
   3. Exit

Select mode (1/2/3): 1

📄 Enter paper information:

Paper path (.docx file): /home/user/papers/my_paper.docx

📝 Briefly describe your paper's topic:
   (e.g., 'Byzantine Greek corpus linguistics', 'Historical syntax', etc.)
Topic: Byzantine Greek corpus linguistics

📁 Output directory:
   (press Enter for same directory as paper): 

[Tool processes paper...]

✅ VERIFICATION COMPLETE!
```

### **Method 2: Command Line** (Fast)

**Single paper:**
```bash
python3 verify_paper.py my_paper.docx
# Will prompt for topic description
```

**Multiple papers:**
```bash
python3 verify_paper.py paper1.docx paper2.docx paper3.docx
# Will prompt for overall topic
```

### **Method 3: Python Script** (Advanced)

Create your own script:

```python
from paper_verifier import PaperVerifier

# Initialize
verifier = PaperVerifier()

# Verify single paper
result = verifier.verify_paper(
    'my_paper.docx',
    'Byzantine Greek corpus linguistics'
)

# Check results
print(f"Found {len(result.contradictions)} contradictions")

for contr in result.contradictions:
    print(f"- {contr.type}: {contr.description}")

# Mark document
verifier.mark_document(
    'my_paper.docx',
    'my_paper_VERIFIED.docx',
    [], [],
    result.contradictions
)

# Generate report
verifier.generate_report([result], 'report.md')
```

---

## 📊 **UNDERSTANDING THE RESULTS**

### **Output Files**

After verification, you get:

1. **`[filename]_VERIFIED.docx`** - Your paper with issues marked
   - 🟢 **BOLD GREEN** = Severe issues
   - 🟠 **ORANGE** = Moderate issues
   - Corrections page added at end

2. **`[filename]_REPORT.md`** - Detailed text report
   - All contradictions listed
   - Statistics
   - Citations inventory
   - Fix recommendations

3. **`COMPREHENSIVE_VERIFICATION_REPORT.md`** - For multiple papers
   - Individual paper results
   - Cross-paper analysis
   - Common citations
   - Overall statistics

### **Contradiction Types**

#### **🔴 SEVERE**

**1. TEMPORAL_CONTRADICTION**
- **What it detects:** Citations to years that don't make sense
- **Example:** Citing "Author 2009" when book published in 2022
- **Impact:** Undermines bibliography credibility
- **Fix:** Correct the year

**2. THEMATIC_MISMATCH**
- **What it detects:** References completely unrelated to paper topic
- **Example:** "Urban Education" book in Greek linguistics paper
- **Impact:** Suggests references weren't checked
- **Fix:** Replace with relevant reference

#### **🟠 MODERATE**

**3. ATTRIBUTION_INCONSISTENCY**
- **What it detects:** Same work cited different ways
- **Example:** "Haug & Jøhndal 2008" AND "Jøhndal 2008" (alone)
- **Impact:** Creates confusion - looks like different sources
- **Fix:** Standardize to full author list

#### **🟡 MINOR**

**4. TEMPORAL_RANGE**
- **What it detects:** Same author cited across unusual time span (>15 years)
- **Example:** "Smith 1990" and "Smith 2023" in same paper
- **Impact:** Might be correct, but worth verifying
- **Fix:** Double-check all citations are accurate

---

## 💡 **EXAMPLES FROM YOUR PAPERS**

### **Example 1: Lavidas 2009 Error**

**What was found:**
```
🔴 TEMPORAL_CONTRADICTION
Issue: Lavidas (2009) cited but book published in 2022
Impact: SEVERE - undermines bibliography credibility
Fix: Change all instances to "Lavidas & Nikiforidou (2022)"
Locations: Paragraphs 71, 90, 99, 134
```

**How it was marked:**
- All "(Lavidas 2009" text marked in **BOLD GREEN**
- Corrections page explains the error
- Report lists all locations

**How to fix:**
1. Open `_VERIFIED.docx` file
2. Find BOLD GREEN text
3. Replace "(Lavidas 2009" with "(Lavidas & Nikiforidou 2022"
4. Update reference list

### **Example 2: Wrong Reference**

**What was found:**
```
🔴 THEMATIC_MISMATCH
Issue: Adams (2003) listed as "Urban Education" 
       Paper topic: Byzantine Greek linguistics
Impact: Reference completely irrelevant to paper topic
Fix: Replace with: Adams, J.N. - Bilingualism and the Latin Language
```

**How it was marked:**
- Error noted in corrections page
- Report explains the problem

**How to fix:**
1. Go to reference list
2. Find Adams (2003) entry
3. Replace with correct book title

### **Example 3: Attribution Inconsistency**

**What was found:**
```
🟠 ATTRIBUTION_INCONSISTENCY
Issue: Work cited as both "Haug & Jøhndal (2008)" 
       and "Jøhndal (2008)" in same paper
Impact: Creates ambiguity - appears to be two different sources
Fix: Standardize to full author list: "Haug & Jøhndal (2008)"
```

**How it was marked:**
- Both citation forms marked in **ORANGE**
- Locations listed

**How to fix:**
1. Search document for "Jøhndal (2008)"
2. Replace with "Haug & Jøhndal (2008)"
3. Ensure reference list has full entry

---

## 🔧 **CUSTOMIZATION**

### **Adding Custom Checks**

Edit `paper_verifier.py` to add your own checks:

```python
class ContradictionDetector:
    
    @staticmethod
    def check_custom_pattern(citations, paragraphs):
        """Add your custom contradiction check here."""
        contradictions = []
        
        # Your logic here
        # Example: Check for specific author patterns
        for cit in citations:
            if 'YourName' in cit.author and cit.year < '2020':
                contradictions.append(Contradiction(
                    type="OUTDATED_SELF_CITATION",
                    severity="MINOR",
                    description=f"Old self-citation: {cit.text}",
                    locations=[cit.paragraph_idx],
                    impact="Consider citing more recent work",
                    fix="Update to latest publication"
                ))
        
        return contradictions
```

Then add to `PaperVerifier.verify_paper()`:
```python
custom_contradictions = self.detector.check_custom_pattern(
    citations, paragraphs
)
all_contradictions.extend(custom_contradictions)
```

### **Changing Colors**

Edit color definitions at top of `paper_verifier.py`:

```python
# Current colors
BOLD_GREEN = RGBColor(0, 200, 0)   # Errors
ORANGE = RGBColor(255, 165, 0)      # Warnings

# Change to your preference
BOLD_GREEN = RGBColor(255, 0, 0)    # Red for errors
ORANGE = RGBColor(0, 0, 255)        # Blue for warnings
```

### **Adding Fields to Check**

To check if references match specific fields:

```python
# In ContradictionDetector.check_thematic_contradictions()

# Add your field keywords
topic_keywords = {
    'linguistics': ['language', 'syntax', 'grammar'],
    'greek': ['greek', 'byzantine', 'classical'],
    'your_field': ['keyword1', 'keyword2', 'keyword3'],  # ADD HERE
}

# Add obviously wrong topics
obviously_wrong = [
    ('urban education', 'education theory'),
    ('your_wrong_topic', 'wrong field'),  # ADD HERE
]
```

---

## 📋 **TROUBLESHOOTING**

### **Common Issues**

**1. "Package not found" error**
```bash
# Solution: Install python-docx
pip install python-docx
```

**2. "No citations found"**
- Check if your citations use standard format: (Author Year) or Author (Year)
- Tool supports: (Author 2020), (Author & Author 2020), Author (2020, pp. XX)
- If using different format, citations may not be detected

**3. "File not found"**
```bash
# Use absolute path
python3 verify_paper.py /full/path/to/paper.docx

# Or navigate to paper directory first
cd /path/to/papers
python3 /path/to/tool/verify_paper.py paper.docx
```

**4. "Permission denied"**
```bash
# Make script executable
chmod +x verify_paper.py

# Then run
./verify_paper.py paper.docx
```

**5. Tool runs but no contradictions found**
- This is good! It means no contradictions detected
- Check marked document - may still have some markings
- Review report for citation list

### **Getting Help**

If you encounter issues:

1. Check this guide
2. Look at examples in `/examples/` folder
3. Review the code comments in `paper_verifier.py`
4. Check Python version: `python3 --version` (need 3.7+)

---

## 🎯 **BEST PRACTICES**

### **Before Running Tool**

1. ✅ Save a backup copy of your paper
2. ✅ Ensure paper is in .docx format (not .doc)
3. ✅ Close the document in Word
4. ✅ Know your paper's general topic area

### **Using Results**

1. ✅ Review marked document first (visual overview)
2. ✅ Read detailed report (full explanations)
3. ✅ Fix severe contradictions first
4. ✅ Then moderate, then minor
5. ✅ Run tool again after fixes to verify

### **For Multiple Papers**

1. ✅ Use same topic description for related papers
2. ✅ Review cross-paper analysis section
3. ✅ Check for systematic errors (appear in multiple papers)
4. ✅ Fix systematic errors in all papers at once

### **Regular Use**

Run this tool:
- ✅ Before submitting papers for review
- ✅ After major revisions
- ✅ When adding many new citations
- ✅ As part of final proofreading

---

## 📚 **WHAT THE TOOL DETECTS**

### **Currently Detects:**

✅ Temporal contradictions (wrong years)  
✅ Attribution inconsistencies (same work cited differently)  
✅ Thematic mismatches (irrelevant references)  
✅ Unusual citation patterns (same author across long time spans)  
✅ Duplicate/missing co-authors  

### **Limitations:**

⚠️ **Does NOT verify:**
- Page number accuracy (you must check)
- DOI correctness
- Publication venue names
- Author name spellings (beyond obvious errors)

⚠️ **Requires manual verification:**
- Whether citations are to correct edition
- If page ranges are accurate
- Whether works are actually relevant (tool flags obvious mismatches only)

⚠️ **Cannot detect:**
- Missing citations (works you should have cited but didn't)
- Plagiarism or improper paraphrasing
- Whether arguments are logically sound

**The tool is a verification assistant, not a replacement for careful scholarship!**

---

## 🔄 **VERSION HISTORY**

### **Version 1.0** (December 2025)
- Initial release
- Citation extraction
- Contradiction detection (3 types)
- Document marking
- Report generation
- Cross-paper analysis

---

## 📞 **SUPPORT**

Created specifically for Professor Nikolaos Lavidas based on comprehensive analysis of academic papers in:
- Byzantine Greek linguistics
- Historical corpus linguistics
- Translation studies
- Computational linguistics

The tool embodies all strategies used in the manual verification of your papers.

---

## ✅ **CHECKLIST FOR FIRST USE**

- [ ] Python 3.7+ installed
- [ ] python-docx installed (`pip install python-docx`)
- [ ] Tool folder downloaded and extracted
- [ ] Test paper ready (.docx format)
- [ ] Paper topic identified
- [ ] Output directory chosen
- [ ] Backup of original paper made
- [ ] Ready to run!

---

**Happy verifying! 🎯**
