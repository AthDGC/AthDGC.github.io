#!/usr/bin/env python3
"""
COMPLETE PAPER VERIFICATION TOOL
=================================

ALL FEATURES from beginning of chat:
✅ Citation extraction from Word docs
✅ Contradiction detection (temporal, attribution, thematic)
✅ API verification (CrossRef, Semantic Scholar, OpenAlex)
✅ DOI lookup and verification
✅ Automatic reference list generation
✅ Page number checking
✅ Author name verification
✅ Document marking (BOLD GREEN for errors)
✅ Comprehensive reports
✅ Cross-paper analysis

NO API KEYS REQUIRED - All free APIs!
"""

import os
import sys
from pathlib import Path

try:
    from paper_verifier import PaperVerifier, Citation, Contradiction
    from citation_apis import CitationAPIVerifier, VerifiedCitation
except ImportError:
    print("❌ Error: Required modules not found")
    print("   Make sure you're in the paper_verification_tool directory")
    sys.exit(1)


class CompletePaperVerifier:
    """
    Complete verification with ALL features.
    Combines local analysis + API verification.
    """
    
    def __init__(self, use_apis: bool = True):
        """
        Initialize complete verifier.
        
        Args:
            use_apis: Whether to use online APIs for verification
        """
        self.local_verifier = PaperVerifier()
        self.api_verifier = CitationAPIVerifier() if use_apis else None
        self.use_apis = use_apis
    
    def verify_paper_complete(self, doc_path: str, paper_topic: str,
                             verify_with_apis: bool = None):
        """
        Complete verification: local analysis + API verification.
        
        Args:
            doc_path: Path to Word document
            paper_topic: Brief description of paper topic
            verify_with_apis: Override to enable/disable API verification
            
        Returns:
            Enhanced verification result with API data
        """
        use_apis = verify_with_apis if verify_with_apis is not None else self.use_apis
        
        print(f"\n{'='*80}")
        print(f"COMPLETE VERIFICATION")
        print(f"Paper: {os.path.basename(doc_path)}")
        print(f"Topic: {paper_topic}")
        print(f"API Verification: {'Enabled' if use_apis else 'Disabled'}")
        print(f"{'='*80}\n")
        
        # Step 1: Local analysis (contradiction detection)
        print("📋 Phase 1: Local Analysis")
        print("-" * 80)
        local_result = self.local_verifier.verify_paper(doc_path, paper_topic)
        
        # Step 2: API verification (if enabled)
        verified_citations = {}
        
        if use_apis and self.api_verifier:
            print("\n📡 Phase 2: API Verification")
            print("-" * 80)
            print("   Verifying citations with online databases...")
            print("   (This may take a minute...)\n")
            
            for i, citation in enumerate(local_result.citations, 1):
                print(f"   [{i}/{len(local_result.citations)}] {citation.author} ({citation.year})")
                
                verified = self.api_verifier.verify_citation(
                    citation.author,
                    citation.year,
                    None  # Could add title hints if available
                )
                
                verified_citations[f"{citation.author}_{citation.year}"] = verified
                
                if verified.verified:
                    print(f"      ✅ Verified via {verified.source_api}")
                    if verified.issues:
                        for issue in verified.issues:
                            print(f"      ⚠️  {issue}")
                else:
                    print(f"      ❌ Could not verify")
        
        # Step 3: Combine results
        print("\n" + "=" * 80)
        print("VERIFICATION SUMMARY")
        print("=" * 80 + "\n")
        
        # Local analysis summary
        print("📊 LOCAL ANALYSIS:")
        print(f"   Citations found: {local_result.statistics['total_citations']}")
        print(f"   Contradictions:")
        print(f"      🔴 Severe: {local_result.statistics['contradictions']['severe']}")
        print(f"      🟠 Moderate: {local_result.statistics['contradictions']['moderate']}")
        print(f"      🟡 Minor: {local_result.statistics['contradictions']['minor']}")
        
        # API verification summary
        if use_apis and verified_citations:
            verified_count = sum(1 for v in verified_citations.values() if v.verified)
            print(f"\n📡 API VERIFICATION:")
            print(f"   Total checked: {len(verified_citations)}")
            print(f"   Verified: {verified_count}")
            print(f"   Not found: {len(verified_citations) - verified_count}")
        
        # Store API results in local_result
        local_result.api_verification = verified_citations if use_apis else {}
        
        return local_result
    
    def generate_complete_report(self, result, output_path: str):
        """
        Generate comprehensive report with API verification data.
        
        Args:
            result: Verification result with API data
            output_path: Path for output report
        """
        print(f"\n📊 Generating complete report...")
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write("# COMPLETE PAPER VERIFICATION REPORT\n\n")
            f.write(f"**Paper:** {result.filename}\n")
            f.write(f"**Topic:** {result.paper_topic}\n\n")
            f.write("---\n\n")
            
            # Local contradictions
            f.write("## CONTRADICTION ANALYSIS\n\n")
            
            if result.contradictions:
                for i, contr in enumerate(result.contradictions, 1):
                    severity_symbol = {'SEVERE': '🔴', 'MODERATE': '🟠', 'MINOR': '🟡'}
                    f.write(f"### {i}. {severity_symbol.get(contr.severity, '⚠️')} {contr.type}\n\n")
                    f.write(f"**Issue:** {contr.description}\n\n")
                    f.write(f"**Impact:** {contr.impact}\n\n")
                    f.write(f"**Fix:** {contr.fix}\n\n")
                    if contr.locations:
                        f.write(f"**Locations:** Paragraphs {', '.join(map(str, contr.locations[:10]))}\n\n")
            else:
                f.write("✅ No contradictions detected.\n\n")
            
            f.write("---\n\n")
            
            # API verification results
            if hasattr(result, 'api_verification') and result.api_verification:
                f.write("## API VERIFICATION RESULTS\n\n")
                
                verified_cits = [v for v in result.api_verification.values() if v.verified]
                unverified_cits = [v for v in result.api_verification.values() if not v.verified]
                
                # Verified citations
                if verified_cits:
                    f.write(f"### ✅ Verified Citations ({len(verified_cits)})\n\n")
                    
                    for vcit in verified_cits:
                        f.write(f"**{vcit.original_citation}**\n\n")
                        f.write(f"- **Title:** {vcit.title}\n")
                        if vcit.authors:
                            authors_str = ', '.join(vcit.authors[:3])
                            if len(vcit.authors) > 3:
                                authors_str += f" et al. ({len(vcit.authors)} total)"
                            f.write(f"- **Authors:** {authors_str}\n")
                        if vcit.journal:
                            f.write(f"- **Journal:** {vcit.journal}\n")
                        if vcit.doi:
                            f.write(f"- **DOI:** {vcit.doi}\n")
                        if vcit.url:
                            f.write(f"- **URL:** {vcit.url}\n")
                        f.write(f"- **Verified via:** {vcit.source_api}\n")
                        
                        # Generate formatted reference
                        if self.api_verifier:
                            formatted = self.api_verifier.generate_formatted_reference(vcit)
                            f.write(f"\n**Formatted Reference (APA):**\n```\n{formatted}\n```\n")
                        
                        if vcit.issues:
                            f.write(f"\n⚠️ **Issues:**\n")
                            for issue in vcit.issues:
                                f.write(f"- {issue}\n")
                        
                        f.write("\n")
                
                # Unverified citations
                if unverified_cits:
                    f.write(f"\n### ❌ Could Not Verify ({len(unverified_cits)})\n\n")
                    f.write("These citations could not be found in online databases.\n")
                    f.write("This might mean:\n")
                    f.write("- Citation is to a book chapter, edited volume, or conference paper not indexed\n")
                    f.write("- Work is too recent or too old to be in databases\n")
                    f.write("- Citation details (author, year) are incorrect\n\n")
                    
                    for vcit in unverified_cits:
                        f.write(f"- **{vcit.original_citation}**\n")
                        if vcit.issues:
                            for issue in vcit.issues:
                                f.write(f"  - {issue}\n")
                    
                    f.write("\n")
                
                f.write("---\n\n")
            
            # All citations list
            f.write("## COMPLETE CITATIONS LIST\n\n")
            unique_cits = sorted(set([(c.author, c.year) for c in result.citations]))
            for author, year in unique_cits:
                # Check if we have API data
                key = f"{author}_{year}"
                if hasattr(result, 'api_verification') and key in result.api_verification:
                    vcit = result.api_verification[key]
                    if vcit.verified:
                        f.write(f"- ✅ {author} ({year}) - {vcit.title[:80]}...\n")
                    else:
                        f.write(f"- ❓ {author} ({year}) - Not verified\n")
                else:
                    f.write(f"- {author} ({year})\n")
            
            f.write("\n---\n\n")
            
            # Statistics
            f.write("## STATISTICS\n\n")
            f.write(f"- Total citations: {result.statistics['total_citations']}\n")
            f.write(f"- Unique citations: {result.statistics['unique_citations']}\n")
            
            if hasattr(result, 'api_verification'):
                verified_count = sum(1 for v in result.api_verification.values() if v.verified)
                f.write(f"- API verified: {verified_count}/{len(result.api_verification)}\n")
            
            f.write(f"- Contradictions found: {len(result.contradictions)}\n")
            f.write(f"  - Severe: {result.statistics['contradictions']['severe']}\n")
            f.write(f"  - Moderate: {result.statistics['contradictions']['moderate']}\n")
            f.write(f"  - Minor: {result.statistics['contradictions']['minor']}\n")
        
        print(f"   ✓ Complete report saved: {os.path.basename(output_path)}")
    
    def generate_corrected_references(self, result, output_path: str):
        """
        Generate properly formatted reference list using API data.
        
        Args:
            result: Verification result with API data
            output_path: Path for reference list file
        """
        if not hasattr(result, 'api_verification') or not result.api_verification:
            print("   ⚠️  No API verification data - cannot generate references")
            return
        
        print(f"\n📚 Generating corrected reference list...")
        
        verified_cits = [v for v in result.api_verification.values() if v.verified]
        
        if not verified_cits:
            print("   ⚠️  No verified citations - cannot generate references")
            return
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write("# CORRECTED REFERENCE LIST\n\n")
            f.write(f"**Generated from:** {result.filename}\n")
            f.write(f"**Format:** APA Style\n")
            f.write(f"**Verified entries:** {len(verified_cits)}\n\n")
            f.write("---\n\n")
            
            # Sort by author
            verified_cits.sort(key=lambda x: x.authors[0] if x.authors else "ZZZ")
            
            for vcit in verified_cits:
                if self.api_verifier:
                    formatted = self.api_verifier.generate_formatted_reference(vcit)
                    f.write(f"{formatted}\n\n")
        
        print(f"   ✓ Reference list saved: {os.path.basename(output_path)}")


def main():
    """Main entry point for complete tool."""
    print("=" * 80)
    print("COMPLETE PAPER VERIFICATION TOOL")
    print("Citation Analysis + API Verification + Contradiction Detection")
    print("=" * 80)
    
    if len(sys.argv) < 2:
        print("\nUsage:")
        print("  python3 verify_paper_complete.py paper.docx")
        print("  python3 verify_paper_complete.py paper.docx --no-api")
        print("\nOptions:")
        print("  --no-api    Skip online API verification (faster, offline mode)")
        return 1
    
    paper_path = sys.argv[1]
    use_apis = '--no-api' not in sys.argv
    
    if not os.path.exists(paper_path):
        print(f"\n❌ Error: File not found: {paper_path}")
        return 1
    
    # Get paper topic
    print(f"\n📄 Paper: {os.path.basename(paper_path)}")
    topic = input("📝 Brief topic description: ").strip()
    
    if not topic:
        topic = "Academic research paper"
    
    # Initialize complete verifier
    verifier = CompletePaperVerifier(use_apis=use_apis)
    
    # Verify
    result = verifier.verify_paper_complete(paper_path, topic)
    
    # Generate outputs
    print("\n" + "=" * 80)
    print("GENERATING OUTPUTS")
    print("=" * 80)
    
    base_name = os.path.splitext(os.path.basename(paper_path))[0]
    output_dir = os.path.dirname(paper_path) or '.'
    
    # Marked document
    marked_path = os.path.join(output_dir, f"{base_name}_COMPLETE_VERIFIED.docx")
    verifier.local_verifier.mark_document(
        paper_path,
        marked_path,
        [], [],
        result.contradictions
    )
    
    # Complete report
    report_path = os.path.join(output_dir, f"{base_name}_COMPLETE_REPORT.md")
    verifier.generate_complete_report(result, report_path)
    
    # Reference list (if API verification was used)
    if use_apis:
        ref_path = os.path.join(output_dir, f"{base_name}_REFERENCES.md")
        verifier.generate_corrected_references(result, ref_path)
    
    print("\n" + "=" * 80)
    print("✅ COMPLETE VERIFICATION DONE!")
    print("=" * 80 + "\n")
    
    print("📄 Output files:")
    print(f"   1. Marked document: {os.path.basename(marked_path)}")
    print(f"   2. Complete report: {os.path.basename(report_path)}")
    if use_apis:
        print(f"   3. Reference list: {os.path.basename(ref_path)}")
    print(f"\n   Location: {output_dir}\n")
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
