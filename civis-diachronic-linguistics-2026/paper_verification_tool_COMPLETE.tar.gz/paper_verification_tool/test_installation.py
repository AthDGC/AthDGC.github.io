#!/usr/bin/env python3
"""
TEST SCRIPT - Verify Tool Installation
=======================================

Quick test to verify the tool is working correctly.
"""

import os
import sys

def test_import():
    """Test if tool can be imported."""
    print("🔧 Testing imports...")
    try:
        from paper_verifier import PaperVerifier, Citation, Contradiction
        print("   ✓ Core tool imported successfully")
        return True
    except ImportError as e:
        print(f"   ❌ Import failed: {e}")
        return False


def test_docx():
    """Test if python-docx is available."""
    print("\n📦 Testing python-docx...")
    try:
        from docx import Document
        print("   ✓ python-docx is installed")
        return True
    except ImportError:
        print("   ❌ python-docx not installed")
        print("   Run: pip install python-docx")
        return False


def test_citation_extraction():
    """Test citation extraction with sample text."""
    print("\n🔍 Testing citation extraction...")
    
    try:
        from paper_verifier import CitationExtractor
        
        # Test patterns
        test_texts = [
            "(Smith 2020)",
            "(Jones & Brown 2019: 45-67)",
            "According to Miller (2021, pp. 123-145)",
            "Davis et al. (2018)",
        ]
        
        extractor = CitationExtractor()
        
        for text in test_texts:
            found = False
            for pattern in extractor.PATTERNS:
                import re
                if re.search(pattern, text):
                    found = True
                    break
            
            if found:
                print(f"   ✓ Detected: {text}")
            else:
                print(f"   ⚠️  Missed: {text}")
        
        return True
        
    except Exception as e:
        print(f"   ❌ Test failed: {e}")
        return False


def test_contradiction_detection():
    """Test contradiction detection logic."""
    print("\n⚠️  Testing contradiction detection...")
    
    try:
        from paper_verifier import ContradictionDetector, Citation
        
        detector = ContradictionDetector()
        
        # Test data: same work cited two ways
        citations = [
            Citation("(Haug & Jøhndal 2008)", "Haug & Jøhndal", "2008", None, 10, "..."),
            Citation("(Jøhndal 2008)", "Jøhndal", "2008", None, 50, "..."),
        ]
        
        contradictions = detector.check_attribution_contradictions(citations)
        
        if contradictions:
            print(f"   ✓ Detected attribution contradiction: {len(contradictions)} found")
        else:
            print(f"   ℹ️  No contradictions in test data")
        
        return True
        
    except Exception as e:
        print(f"   ❌ Test failed: {e}")
        return False


def test_complete():
    """Run complete test if sample paper available."""
    print("\n📄 Looking for sample papers...")
    
    # Look for any .docx files in current directory or examples
    test_papers = []
    
    for directory in ['.', 'examples', '../examples']:
        if os.path.exists(directory):
            for file in os.listdir(directory):
                if file.endswith('.docx') and not file.startswith('~'):
                    test_papers.append(os.path.join(directory, file))
    
    if not test_papers:
        print("   ℹ️  No sample papers found")
        print("   To test with your paper, run:")
        print("   python3 verify_paper.py your_paper.docx")
        return True
    
    print(f"   Found {len(test_papers)} test paper(s)")
    
    try:
        from paper_verifier import PaperVerifier
        
        # Test first paper
        test_paper = test_papers[0]
        print(f"\n   Testing with: {os.path.basename(test_paper)}")
        
        verifier = PaperVerifier()
        result = verifier.verify_paper(test_paper, "Test paper")
        
        print(f"   ✓ Extracted {result.total_citations} citations")
        print(f"   ✓ Found {len(result.contradictions)} contradictions")
        
        return True
        
    except Exception as e:
        print(f"   ❌ Complete test failed: {e}")
        return False


def main():
    """Run all tests."""
    print("=" * 80)
    print("PAPER VERIFICATION TOOL - INSTALLATION TEST")
    print("=" * 80)
    
    tests = [
        ("Import Test", test_import),
        ("Dependencies Test", test_docx),
        ("Citation Extraction", test_citation_extraction),
        ("Contradiction Detection", test_contradiction_detection),
        ("Complete Test", test_complete),
    ]
    
    results = []
    
    for name, test_func in tests:
        result = test_func()
        results.append((name, result))
    
    # Summary
    print("\n" + "=" * 80)
    print("TEST SUMMARY")
    print("=" * 80 + "\n")
    
    passed = sum(1 for _, r in results if r)
    total = len(results)
    
    for name, result in results:
        symbol = "✅" if result else "❌"
        print(f"   {symbol} {name}")
    
    print(f"\n   Passed: {passed}/{total}")
    
    if passed == total:
        print("\n🎉 All tests passed! Tool is ready to use.")
        print("\nNext steps:")
        print("   1. Read USER_GUIDE.md for detailed instructions")
        print("   2. Run: python3 verify_paper.py your_paper.docx")
        print("   3. Or run: python3 verify_paper.py (for interactive mode)")
    else:
        print("\n⚠️  Some tests failed. Please fix issues above.")
        print("\nCommon solutions:")
        print("   - Install python-docx: pip install python-docx")
        print("   - Check Python version: python3 --version (need 3.7+)")
    
    return 0 if passed == total else 1


if __name__ == "__main__":
    sys.exit(main())
