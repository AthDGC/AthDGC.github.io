#!/usr/bin/env python3
"""
CITATION API VERIFICATION MODULE
=================================

Verifies citations using free academic APIs:
- CrossRef (DOI lookup, bibliographic data)
- Semantic Scholar (paper metadata, citations)
- OpenAlex (open scholarly data)
- CORE (open access papers)

NO API KEYS REQUIRED - All free APIs!
"""

import requests
import time
import json
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass


@dataclass
class VerifiedCitation:
    """Verified citation with full metadata."""
    original_citation: str
    verified: bool
    title: Optional[str] = None
    authors: Optional[List[str]] = None
    year: Optional[str] = None
    doi: Optional[str] = None
    journal: Optional[str] = None
    pages: Optional[str] = None
    publisher: Optional[str] = None
    url: Optional[str] = None
    source_api: Optional[str] = None
    confidence: str = "LOW"  # LOW, MEDIUM, HIGH
    issues: List[str] = None
    
    def __post_init__(self):
        if self.issues is None:
            self.issues = []


class CitationAPIVerifier:
    """
    Verifies citations using multiple free academic APIs.
    NO API KEYS NEEDED!
    """
    
    def __init__(self, rate_limit_delay: float = 1.0):
        """
        Initialize API verifier.
        
        Args:
            rate_limit_delay: Seconds to wait between API calls (be polite!)
        """
        self.rate_limit_delay = rate_limit_delay
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'AcademicPaperVerifier/1.0 (mailto:research@university.edu)'
        })
    
    def verify_citation(self, author: str, year: str, 
                       title_hint: Optional[str] = None) -> VerifiedCitation:
        """
        Verify a citation using multiple APIs.
        
        Args:
            author: Author name(s)
            year: Publication year
            title_hint: Optional title or keywords
            
        Returns:
            VerifiedCitation with metadata
        """
        original = f"{author} ({year})"
        
        # Try APIs in order of reliability
        result = None
        
        # 1. Try CrossRef (most reliable for DOI-registered works)
        result = self._verify_crossref(author, year, title_hint)
        if result and result.verified:
            return result
        
        # 2. Try Semantic Scholar (good for CS/AI papers)
        result = self._verify_semantic_scholar(author, year, title_hint)
        if result and result.verified:
            return result
        
        # 3. Try OpenAlex (comprehensive coverage)
        result = self._verify_openalex(author, year, title_hint)
        if result and result.verified:
            return result
        
        # Not found in any API
        return VerifiedCitation(
            original_citation=original,
            verified=False,
            confidence="LOW",
            issues=["Could not verify in any database"]
        )
    
    def _verify_crossref(self, author: str, year: str, 
                        title_hint: Optional[str]) -> Optional[VerifiedCitation]:
        """
        Verify using CrossRef API (free, no key needed).
        Best for journal articles, books with DOIs.
        """
        try:
            # Clean author name
            author_surname = author.split()[-1].strip()
            
            # Build query
            query_parts = [author_surname, year]
            if title_hint:
                query_parts.append(title_hint)
            
            query = ' '.join(query_parts)
            
            url = "https://api.crossref.org/works"
            params = {
                'query': query,
                'rows': 5,
                'select': 'DOI,title,author,published-print,published-online,container-title,page,publisher'
            }
            
            response = self.session.get(url, params=params, timeout=10)
            
            if response.status_code != 200:
                return None
            
            data = response.json()
            
            if not data.get('message', {}).get('items'):
                return None
            
            # Get best match
            item = data['message']['items'][0]
            
            # Extract metadata
            title = item.get('title', [None])[0]
            authors = [f"{a.get('given', '')} {a.get('family', '')}".strip() 
                      for a in item.get('author', [])]
            
            # Get year
            pub_date = (item.get('published-print') or 
                       item.get('published-online') or 
                       {})
            found_year = str(pub_date.get('date-parts', [[None]])[0][0]) if pub_date else None
            
            doi = item.get('DOI')
            journal = item.get('container-title', [None])[0]
            pages = item.get('page')
            publisher = item.get('publisher')
            
            # Check if year matches
            year_matches = found_year and found_year == year
            
            # Check if author matches (fuzzy)
            author_matches = any(author_surname.lower() in a.lower() for a in authors)
            
            verified = year_matches and author_matches
            confidence = "HIGH" if verified else "MEDIUM"
            
            issues = []
            if not year_matches and found_year:
                issues.append(f"Year mismatch: cited {year}, found {found_year}")
            if not author_matches:
                issues.append(f"Author mismatch: cited {author}, found {', '.join(authors[:2])}")
            
            time.sleep(self.rate_limit_delay)  # Rate limiting
            
            return VerifiedCitation(
                original_citation=f"{author} ({year})",
                verified=verified,
                title=title,
                authors=authors,
                year=found_year,
                doi=doi,
                journal=journal,
                pages=pages,
                publisher=publisher,
                url=f"https://doi.org/{doi}" if doi else None,
                source_api="CrossRef",
                confidence=confidence,
                issues=issues
            )
            
        except Exception as e:
            print(f"   ⚠️  CrossRef error: {e}")
            return None
    
    def _verify_semantic_scholar(self, author: str, year: str,
                                 title_hint: Optional[str]) -> Optional[VerifiedCitation]:
        """
        Verify using Semantic Scholar API (free, no key needed).
        Good for CS, AI, and interdisciplinary papers.
        """
        try:
            # Build query
            query = f"{author} {year}"
            if title_hint:
                query += f" {title_hint}"
            
            url = "https://api.semanticscholar.org/graph/v1/paper/search"
            params = {
                'query': query,
                'limit': 5,
                'fields': 'title,authors,year,venue,publicationDate,doi,url'
            }
            
            response = self.session.get(url, params=params, timeout=10)
            
            if response.status_code != 200:
                return None
            
            data = response.json()
            
            if not data.get('data'):
                return None
            
            # Get best match
            paper = data['data'][0]
            
            title = paper.get('title')
            authors = [a.get('name') for a in paper.get('authors', [])]
            found_year = str(paper.get('year')) if paper.get('year') else None
            venue = paper.get('venue')
            doi = paper.get('doi')
            url = paper.get('url')
            
            # Verify
            year_matches = found_year and found_year == year
            author_surname = author.split()[-1].lower()
            author_matches = any(author_surname in a.lower() for a in authors)
            
            verified = year_matches and author_matches
            confidence = "HIGH" if verified else "MEDIUM"
            
            issues = []
            if not year_matches and found_year:
                issues.append(f"Year mismatch: cited {year}, found {found_year}")
            if not author_matches:
                issues.append(f"Author mismatch: cited {author}, found {', '.join(authors[:2])}")
            
            time.sleep(self.rate_limit_delay)
            
            return VerifiedCitation(
                original_citation=f"{author} ({year})",
                verified=verified,
                title=title,
                authors=authors,
                year=found_year,
                doi=doi,
                journal=venue,
                url=url,
                source_api="Semantic Scholar",
                confidence=confidence,
                issues=issues
            )
            
        except Exception as e:
            print(f"   ⚠️  Semantic Scholar error: {e}")
            return None
    
    def _verify_openalex(self, author: str, year: str,
                        title_hint: Optional[str]) -> Optional[VerifiedCitation]:
        """
        Verify using OpenAlex API (free, no key needed).
        Comprehensive open scholarly data.
        """
        try:
            # Clean author
            author_surname = author.split()[-1].strip()
            
            # Build query
            query_parts = [author_surname, year]
            if title_hint:
                query_parts.append(title_hint)
            query = ' '.join(query_parts)
            
            url = "https://api.openalex.org/works"
            params = {
                'search': query,
                'per_page': 5
            }
            
            response = self.session.get(url, params=params, timeout=10)
            
            if response.status_code != 200:
                return None
            
            data = response.json()
            
            if not data.get('results'):
                return None
            
            # Get best match
            work = data['results'][0]
            
            title = work.get('title')
            
            # Extract authors
            authorships = work.get('authorships', [])
            authors = [a.get('author', {}).get('display_name') 
                      for a in authorships if a.get('author')]
            
            # Get year
            found_year = str(work.get('publication_year')) if work.get('publication_year') else None
            
            # Get other metadata
            doi = work.get('doi', '').replace('https://doi.org/', '')
            venue = work.get('primary_location', {}).get('source', {}).get('display_name')
            url = work.get('doi')
            
            # Verify
            year_matches = found_year and found_year == year
            author_matches = any(author_surname.lower() in (a or '').lower() for a in authors)
            
            verified = year_matches and author_matches
            confidence = "HIGH" if verified else "MEDIUM"
            
            issues = []
            if not year_matches and found_year:
                issues.append(f"Year mismatch: cited {year}, found {found_year}")
            if not author_matches:
                issues.append(f"Author mismatch: cited {author}, found {', '.join(authors[:2])}")
            
            time.sleep(self.rate_limit_delay)
            
            return VerifiedCitation(
                original_citation=f"{author} ({year})",
                verified=verified,
                title=title,
                authors=authors,
                year=found_year,
                doi=doi,
                journal=venue,
                url=url,
                source_api="OpenAlex",
                confidence=confidence,
                issues=issues
            )
            
        except Exception as e:
            print(f"   ⚠️  OpenAlex error: {e}")
            return None
    
    def verify_doi(self, doi: str) -> Optional[VerifiedCitation]:
        """
        Verify a citation directly by DOI.
        
        Args:
            doi: Digital Object Identifier
            
        Returns:
            VerifiedCitation with full metadata
        """
        try:
            url = f"https://api.crossref.org/works/{doi}"
            
            response = self.session.get(url, timeout=10)
            
            if response.status_code != 200:
                return None
            
            item = response.json()['message']
            
            # Extract all metadata
            title = item.get('title', [None])[0]
            authors = [f"{a.get('given', '')} {a.get('family', '')}".strip() 
                      for a in item.get('author', [])]
            
            pub_date = (item.get('published-print') or 
                       item.get('published-online') or 
                       {})
            year = str(pub_date.get('date-parts', [[None]])[0][0]) if pub_date else None
            
            journal = item.get('container-title', [None])[0]
            pages = item.get('page')
            publisher = item.get('publisher')
            
            time.sleep(self.rate_limit_delay)
            
            return VerifiedCitation(
                original_citation=f"DOI: {doi}",
                verified=True,
                title=title,
                authors=authors,
                year=year,
                doi=doi,
                journal=journal,
                pages=pages,
                publisher=publisher,
                url=f"https://doi.org/{doi}",
                source_api="CrossRef (DOI)",
                confidence="HIGH"
            )
            
        except Exception as e:
            print(f"   ⚠️  DOI verification error: {e}")
            return None
    
    def generate_formatted_reference(self, citation: VerifiedCitation,
                                    style: str = "APA") -> str:
        """
        Generate properly formatted reference.
        
        Args:
            citation: Verified citation
            style: Citation style (APA, Chicago, MLA)
            
        Returns:
            Formatted reference string
        """
        if not citation.verified or not citation.authors:
            return f"[Could not verify: {citation.original_citation}]"
        
        if style.upper() == "APA":
            # APA format
            # Authors (Year). Title. Journal, Volume(Issue), pages. DOI
            
            # Format authors
            if len(citation.authors) == 1:
                authors_str = citation.authors[0]
            elif len(citation.authors) == 2:
                authors_str = f"{citation.authors[0]} & {citation.authors[1]}"
            elif len(citation.authors) <= 20:
                authors_str = ", ".join(citation.authors[:-1]) + f", & {citation.authors[-1]}"
            else:
                authors_str = ", ".join(citation.authors[:19]) + ", ... " + citation.authors[-1]
            
            ref = f"{authors_str} ({citation.year}). {citation.title}."
            
            if citation.journal:
                ref += f" {citation.journal}"
                if citation.pages:
                    ref += f", {citation.pages}"
                ref += "."
            elif citation.publisher:
                ref += f" {citation.publisher}."
            
            if citation.doi:
                ref += f" https://doi.org/{citation.doi}"
            
            return ref
        
        else:
            # Basic format
            authors_str = ", ".join(citation.authors) if citation.authors else "Unknown"
            return f"{authors_str} ({citation.year}). {citation.title}."


def demo():
    """Demo the API verifier."""
    print("=" * 80)
    print("CITATION API VERIFICATION - DEMO")
    print("=" * 80)
    
    verifier = CitationAPIVerifier()
    
    # Test cases
    test_citations = [
        ("Haug", "2008", "parallel treebank"),
        ("Toury", "1995", "translation studies"),
        ("Biber", "2009", "register genre style"),
    ]
    
    print("\nTesting citation verification:\n")
    
    for author, year, hint in test_citations:
        print(f"Verifying: {author} ({year}) - '{hint}'")
        
        result = verifier.verify_citation(author, year, hint)
        
        if result.verified:
            print(f"   ✅ VERIFIED via {result.source_api}")
            print(f"   Title: {result.title}")
            print(f"   Authors: {', '.join(result.authors[:2])}{'...' if len(result.authors) > 2 else ''}")
            if result.doi:
                print(f"   DOI: {result.doi}")
        else:
            print(f"   ❌ Not verified: {', '.join(result.issues)}")
        
        print()


if __name__ == "__main__":
    demo()
