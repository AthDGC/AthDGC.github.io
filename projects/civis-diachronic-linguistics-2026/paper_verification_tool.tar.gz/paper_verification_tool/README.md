# 📚 Comprehensive Paper Verification Tool

**Complete citation verification + contradiction analysis for academic papers**

Created for Professor Nikolaos Lavidas - December 2025

---

## 🎯 What It Does

This tool performs **comprehensive verification** of academic papers:

### ✅ Citation Verification
- Extracts ALL citations from Word documents
- Identifies unique vs duplicate citations
- Lists all works cited

### ✅ Contradiction Analysis
- **Temporal contradictions** - Wrong years, impossible dates
- **Attribution contradictions** - Same work cited different ways  
- **Thematic contradictions** - References don't match paper topic

### ✅ Document Marking
- Marks issues in **BOLD GREEN** (severe) or **ORANGE** (moderate)
- Adds detailed corrections page
- Easy to find and fix errors

### ✅ Comprehensive Reporting
- Detailed markdown reports
- Statistics and summaries
- Cross-paper analysis for multiple papers

---

## 🚀 Quick Start

### Installation

```bash
# 1. Install Python 3.7+ (if not already installed)
# Check version:
python3 --version

# 2. Install required package
pip install python-docx

# 3. Test installation
python3 test_installation.py
```

### Basic Usage

```bash
# Interactive mode (easiest)
python3 verify_paper.py

# Single paper
python3 verify_paper.py your_paper.docx

# Multiple papers
python3 verify_paper.py paper1.docx paper2.docx
```

---

## 📁 Files Included

```
paper_verification_tool/
├── README.md                  ← You are here
├── USER_GUIDE.md             ← Detailed instructions & examples
├── paper_verifier.py         ← Core verification engine
├── verify_paper.py           ← Easy-to-use interface
├── test_installation.py      ← Test if tool works
└── examples/                 ← Example papers (optional)
```

---

## 📖 Documentation

- **Quick start:** This README
- **Detailed guide:** [USER_GUIDE.md](USER_GUIDE.md)
  - Complete usage instructions
  - Examples from your papers
  - Troubleshooting
  - Customization options

---

## 💡 Example: What It Finds

### From Your Papers:

**🔴 SEVERE: Temporal Contradiction**
```
Issue: Cites "Lavidas (2009)" but book published in 2022
Impact: Undermines bibliography credibility
Fix: Change to "Lavidas & Nikiforidou (2022)"
Found in: 4 locations
```

**🔴 SEVERE: Thematic Mismatch**
```
Issue: Reference "Urban Education" in Greek linguistics paper
Impact: Completely irrelevant reference
Fix: Replace with Adams - Bilingualism and the Latin Language
```

**🟠 MODERATE: Attribution Inconsistency**
```
Issue: Work cited as "Haug & Jøhndal (2008)" AND "Jøhndal (2008)"
Impact: Looks like two different sources
Fix: Standardize to "Haug & Jøhndal (2008)"
Found in: 2 locations
```

---

## 📊 What You Get

After running the tool on your paper:

### 1. Marked Document (`paper_VERIFIED.docx`)
- Your paper with issues highlighted
- **Green** = severe issues
- **Orange** = moderate issues  
- Corrections page added at end

### 2. Detailed Report (`paper_REPORT.md`)
- All contradictions explained
- Where to find each issue
- How to fix each issue
- Complete citation inventory
- Statistics

### 3. For Multiple Papers: Cross-Analysis
- Common citations across papers
- Systematic errors
- Overall statistics

---

## 🎓 Based On Your Papers

This tool embodies **all strategies** used to verify your papers:

✅ **Paper 1:** Byzantine Greek ATHDGC Corpus  
✅ **Paper 2:** Diachronic Valency Dataset

Found issues like:
- Lavidas 2009 error (systematic across papers)
- Wrong references (Urban Education, Green Growth, etc.)
- Inconsistent co-author citations
- Attribution contradictions

**Same thorough verification, now automated!**

---

## 🔧 Requirements

- **Python:** 3.7 or higher
- **Package:** python-docx
- **Input:** Microsoft Word (.docx) files
- **OS:** Windows, Mac, or Linux

---

## 📝 Usage Examples

### Example 1: Single Paper

```bash
$ python3 verify_paper.py my_research.docx

📝 Brief topic description: Byzantine Greek corpus linguistics

[Tool processes...]

✅ VERIFICATION COMPLETE!

Output files:
  1. my_research_VERIFIED.docx
  2. my_research_REPORT.md
```

### Example 2: Multiple Papers

```bash
$ python3 verify_paper.py chapter1.docx chapter2.docx chapter3.docx

📝 Overall topic description: Historical Greek syntax

[Tool processes each paper...]

✅ VERIFICATION COMPLETE!

Output files:
  - 3 marked documents
  - 1 comprehensive report with cross-paper analysis
```

### Example 3: Interactive Mode

```bash
$ python3 verify_paper.py

🔍 VERIFICATION MODE:
   1. Single paper
   2. Multiple papers
   3. Exit

Select mode (1/2/3): 1

[Follow the prompts...]
```

---

## ⚙️ How It Works

### Step 1: Citation Extraction
- Scans entire document
- Identifies all citation patterns
- Extracts author, year, pages

### Step 2: Contradiction Detection
- **Temporal check:** Impossible or suspicious years
- **Attribution check:** Same work cited differently
- **Thematic check:** References don't match topic

### Step 3: Document Marking
- Colors severe issues in **GREEN**
- Colors moderate issues in **ORANGE**
- Adds explanatory corrections page

### Step 4: Report Generation
- Lists all issues with fixes
- Provides statistics
- Cross-references for multiple papers

---

## 🎯 Use Cases

### Before Submission
✅ Verify all citations before journal submission  
✅ Catch errors reviewers would find  
✅ Ensure bibliography consistency  

### During Revision
✅ Check after adding new citations  
✅ Verify consistency across chapters  
✅ Ensure co-author citations correct  

### For Multiple Papers
✅ Check consistency across related papers  
✅ Find systematic errors  
✅ Verify same works cited same way  

### Regular Maintenance
✅ As part of final proofreading  
✅ Before conference presentations  
✅ When updating reference lists  

---

## ❓ FAQs

**Q: Will this catch all errors?**  
A: It catches contradictions and inconsistencies. You still need to verify page numbers, check relevance, and ensure proper paraphrasing.

**Q: Can it verify page numbers?**  
A: No - you must verify pages against original sources. Tool flags citations with page ranges for your review.

**Q: Does it work with non-English papers?**  
A: Yes! Works with Greek, Latin alphabet citations. Pattern-based, language-agnostic.

**Q: What citation styles does it support?**  
A: Currently: (Author Year), Author (Year), (Author & Author Year), Author et al. (Year). Most common academic styles.

**Q: Can I add custom checks?**  
A: Yes! See USER_GUIDE.md section on customization. Add your own contradiction patterns.

**Q: Is my paper data safe?**  
A: Yes! Tool runs locally on your computer. No data sent anywhere. No internet needed.

---

## 🆘 Troubleshooting

### "Package not found"
```bash
pip install python-docx
```

### "No citations found"
- Check if citations use standard format: (Author Year)
- See USER_GUIDE.md for supported formats

### "Permission denied"
```bash
chmod +x verify_paper.py
```

### Still having issues?
1. Run test: `python3 test_installation.py`
2. Check Python version: `python3 --version` (need 3.7+)
3. See USER_GUIDE.md troubleshooting section

---

## 📊 Statistics from Your Papers

### Paper 1 (Byzantine Greek Corpus):
- 23 citations → 5 errors, 1 warning
- **2 severe contradictions** detected
- All marked and fixed

### Paper 2 (Valency Dataset):
- 22 citations → 2 errors, 10 warnings
- **3 contradictions** detected (1 severe, 2 moderate)
- All marked and fixed

### Cross-Paper Analysis:
- **Systematic error found:** "Lavidas 2009" in both papers
- **Consistency verified:** Papers describe same project coherently
- **No contradictions between papers**

---

## ✨ Features

- ✅ **Fast:** Processes papers in seconds
- ✅ **Thorough:** Checks every citation, every paragraph
- ✅ **Accurate:** Based on real paper verification
- ✅ **Easy:** Simple interface, clear output
- ✅ **Comprehensive:** Citation + contradiction analysis
- ✅ **Visual:** Errors marked in documents
- ✅ **Detailed:** Complete reports with fixes
- ✅ **Scalable:** Single or multiple papers
- ✅ **Customizable:** Add your own checks
- ✅ **Local:** Runs on your computer, no internet needed

---

## 📜 License & Attribution

Created for Professor Nikolaos Lavidas, December 2025

Based on comprehensive analysis strategies developed for:
- Byzantine Greek linguistics
- Historical corpus research
- Translation studies
- Computational linguistics

Free to use and modify for academic research.

---

## 🚦 Status

✅ **Ready to use**  
✅ **Tested on real papers**  
✅ **Fully documented**

---

## 📞 Support

1. **Read the guide:** USER_GUIDE.md (detailed instructions)
2. **Run test:** `python3 test_installation.py`
3. **Check examples:** See examples in USER_GUIDE.md

---

## 🎯 Next Steps

1. **Test installation:**
   ```bash
   python3 test_installation.py
   ```

2. **Try on your paper:**
   ```bash
   python3 verify_paper.py your_paper.docx
   ```

3. **Read detailed guide:**
   - Open USER_GUIDE.md
   - See examples from your papers
   - Learn customization options

4. **Use regularly:**
   - Before submissions
   - After revisions
   - For final checks

---

**Happy verifying! 🎓📚✨**
