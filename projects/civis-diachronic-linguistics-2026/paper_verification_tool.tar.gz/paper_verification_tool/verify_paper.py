#!/usr/bin/env python3
"""
INTERACTIVE PAPER VERIFICATION TOOL
====================================

Easy-to-use command-line interface for verifying academic papers.

Usage:
    python verify_paper.py                          # Interactive mode
    python verify_paper.py paper.docx               # Single paper
    python verify_paper.py paper1.docx paper2.docx  # Multiple papers
"""

import sys
import os
from pathlib import Path
from paper_verifier import PaperVerifier, VerificationResult


def print_header():
    """Print tool header."""
    print("\n" + "=" * 80)
    print("COMPREHENSIVE PAPER VERIFICATION TOOL")
    print("Citation Verification + Contradiction Analysis")
    print("=" * 80 + "\n")


def get_paper_info():
    """Interactive prompt for paper information."""
    print("📄 Enter paper information:\n")
    
    # Get paper path
    while True:
        paper_path = input("Paper path (.docx file): ").strip()
        if os.path.exists(paper_path) and paper_path.endswith('.docx'):
            break
        print("❌ File not found or not a .docx file. Try again.\n")
    
    # Get topic
    print("\n📝 Briefly describe your paper's topic:")
    print("   (e.g., 'Byzantine Greek corpus linguistics', 'Historical syntax', etc.)")
    topic = input("Topic: ").strip()
    
    if not topic:
        topic = "Academic research paper"
    
    return paper_path, topic


def verify_single_paper(paper_path: str, topic: str, output_dir: str = None):
    """Verify a single paper."""
    
    if output_dir is None:
        output_dir = os.path.dirname(paper_path) or '.'
    
    # Create output directory
    os.makedirs(output_dir, exist_ok=True)
    
    # Initialize verifier
    verifier = PaperVerifier()
    
    # Verify
    print(f"\n{'='*80}")
    print("STARTING VERIFICATION")
    print(f"{'='*80}")
    
    result = verifier.verify_paper(paper_path, topic)
    
    # Display summary
    print(f"\n{'='*80}")
    print("VERIFICATION COMPLETE")
    print(f"{'='*80}\n")
    
    print(f"📊 SUMMARY:")
    print(f"   Total citations: {result.statistics['total_citations']}")
    print(f"   Unique citations: {result.statistics['unique_citations']}")
    print(f"\n   Contradictions:")
    print(f"      🔴 Severe: {result.statistics['contradictions']['severe']}")
    print(f"      🟠 Moderate: {result.statistics['contradictions']['moderate']}")
    print(f"      🟡 Minor: {result.statistics['contradictions']['minor']}")
    
    # Show contradictions
    if result.contradictions:
        print(f"\n⚠️  ISSUES FOUND:")
        for i, contr in enumerate(result.contradictions, 1):
            severity_symbol = {'SEVERE': '🔴', 'MODERATE': '🟠', 'MINOR': '🟡'}
            symbol = severity_symbol.get(contr.severity, '⚠️')
            print(f"\n   {i}. {symbol} {contr.type}")
            print(f"      {contr.description}")
    else:
        print("\n✅ No contradictions detected!")
    
    # Generate outputs
    print(f"\n{'='*80}")
    print("GENERATING OUTPUTS")
    print(f"{'='*80}\n")
    
    # Base filename
    base_name = os.path.splitext(os.path.basename(paper_path))[0]
    
    # Marked document
    marked_path = os.path.join(output_dir, f"{base_name}_VERIFIED.docx")
    verifier.mark_document(
        paper_path, 
        marked_path,
        [],  # errors handled in contradictions
        [],  # warnings handled in contradictions
        result.contradictions
    )
    
    # Report
    report_path = os.path.join(output_dir, f"{base_name}_REPORT.md")
    verifier.generate_report([result], report_path)
    
    print(f"\n{'='*80}")
    print("✅ VERIFICATION COMPLETE!")
    print(f"{'='*80}\n")
    print("📄 Output files:")
    print(f"   1. Marked document: {os.path.basename(marked_path)}")
    print(f"   2. Report: {os.path.basename(report_path)}")
    print(f"\n   Location: {output_dir}\n")
    
    return result


def verify_multiple_papers(paper_paths: list, topics: list = None, output_dir: str = "."):
    """Verify multiple papers and generate cross-paper analysis."""
    
    if topics is None:
        topics = ["Academic research paper"] * len(paper_paths)
    
    verifier = PaperVerifier()
    results = []
    
    print(f"\n{'='*80}")
    print(f"VERIFYING {len(paper_paths)} PAPERS")
    print(f"{'='*80}")
    
    # Verify each paper
    for i, (paper_path, topic) in enumerate(zip(paper_paths, topics), 1):
        print(f"\n[{i}/{len(paper_paths)}] {os.path.basename(paper_path)}")
        result = verifier.verify_paper(paper_path, topic)
        results.append(result)
        
        # Marked document
        base_name = os.path.splitext(os.path.basename(paper_path))[0]
        marked_path = os.path.join(output_dir, f"{base_name}_VERIFIED.docx")
        verifier.mark_document(
            paper_path,
            marked_path,
            [], [],
            result.contradictions
        )
    
    # Cross-paper analysis
    print(f"\n{'='*80}")
    print("CROSS-PAPER ANALYSIS")
    print(f"{'='*80}\n")
    
    # Check for common errors
    common_authors = {}
    for result in results:
        for cit in result.citations:
            key = f"{cit.author} {cit.year}"
            if key not in common_authors:
                common_authors[key] = []
            common_authors[key].append(result.filename)
    
    # Find citations in multiple papers
    print("Citations appearing in multiple papers:")
    multi_paper_cits = {k: v for k, v in common_authors.items() if len(v) > 1}
    if multi_paper_cits:
        for cit, papers in sorted(multi_paper_cits.items()):
            print(f"   {cit} → {len(papers)} papers")
    else:
        print("   None found (papers cite different works)")
    
    # Generate combined report
    report_path = os.path.join(output_dir, "COMPREHENSIVE_VERIFICATION_REPORT.md")
    verifier.generate_report(results, report_path)
    
    # Add cross-paper section
    with open(report_path, 'a', encoding='utf-8') as f:
        f.write("\n---\n\n")
        f.write("## CROSS-PAPER ANALYSIS\n\n")
        f.write(f"**Papers verified:** {len(results)}\n\n")
        
        f.write("### Citations Appearing in Multiple Papers\n\n")
        if multi_paper_cits:
            for cit, papers in sorted(multi_paper_cits.items()):
                f.write(f"- **{cit}**\n")
                for paper in papers:
                    f.write(f"  - {paper}\n")
                f.write("\n")
        else:
            f.write("No common citations found.\n\n")
        
        # Summary
        f.write("### Overall Statistics\n\n")
        total_cits = sum(r.statistics['total_citations'] for r in results)
        total_severe = sum(r.statistics['contradictions']['severe'] for r in results)
        total_moderate = sum(r.statistics['contradictions']['moderate'] for r in results)
        total_minor = sum(r.statistics['contradictions']['minor'] for r in results)
        
        f.write(f"- Total citations across all papers: {total_cits}\n")
        f.write(f"- Total contradictions found:\n")
        f.write(f"  - 🔴 Severe: {total_severe}\n")
        f.write(f"  - 🟠 Moderate: {total_moderate}\n")
        f.write(f"  - 🟡 Minor: {total_minor}\n")
    
    print(f"\n{'='*80}")
    print("✅ VERIFICATION COMPLETE!")
    print(f"{'='*80}\n")
    print(f"📄 Output files in: {output_dir}")
    print(f"   - {len(results)} marked documents")
    print(f"   - 1 comprehensive report\n")
    
    return results


def interactive_mode():
    """Run in interactive mode."""
    print_header()
    
    print("🔍 VERIFICATION MODE:")
    print("   1. Single paper")
    print("   2. Multiple papers")
    print("   3. Exit")
    
    choice = input("\nSelect mode (1/2/3): ").strip()
    
    if choice == "1":
        # Single paper
        paper_path, topic = get_paper_info()
        
        print("\n📁 Output directory:")
        output_dir = input("   (press Enter for same directory as paper): ").strip()
        if not output_dir:
            output_dir = os.path.dirname(paper_path) or '.'
        
        verify_single_paper(paper_path, topic, output_dir)
        
    elif choice == "2":
        # Multiple papers
        print("\n📄 Enter paper paths (one per line, empty line to finish):\n")
        papers = []
        while True:
            path = input(f"   Paper {len(papers) + 1}: ").strip()
            if not path:
                break
            if os.path.exists(path) and path.endswith('.docx'):
                papers.append(path)
            else:
                print("      ❌ File not found or not .docx. Skipped.")
        
        if not papers:
            print("❌ No valid papers provided.")
            return
        
        print(f"\n📝 Briefly describe overall topic of these papers:")
        topic = input("Topic: ").strip()
        if not topic:
            topic = "Academic research"
        
        topics = [topic] * len(papers)
        
        print("\n📁 Output directory:")
        output_dir = input("   (press Enter for current directory): ").strip()
        if not output_dir:
            output_dir = "."
        
        verify_multiple_papers(papers, topics, output_dir)
        
    elif choice == "3":
        print("\n👋 Goodbye!")
        return
    
    else:
        print("\n❌ Invalid choice. Exiting.")


def main():
    """Main entry point."""
    print_header()
    
    if len(sys.argv) == 1:
        # Interactive mode
        interactive_mode()
        
    elif len(sys.argv) == 2:
        # Single paper
        paper_path = sys.argv[1]
        
        if not os.path.exists(paper_path):
            print(f"❌ Error: File not found: {paper_path}")
            return 1
        
        print(f"📄 Paper: {os.path.basename(paper_path)}")
        topic = input("📝 Brief topic description: ").strip()
        
        if not topic:
            topic = "Academic research paper"
        
        verify_single_paper(paper_path, topic)
        
    else:
        # Multiple papers
        paper_paths = sys.argv[1:]
        
        # Validate all exist
        for path in paper_paths:
            if not os.path.exists(path):
                print(f"❌ Error: File not found: {path}")
                return 1
        
        print(f"📄 Verifying {len(paper_paths)} papers")
        topic = input("📝 Overall topic description: ").strip()
        
        if not topic:
            topic = "Academic research"
        
        verify_multiple_papers(paper_paths, [topic] * len(paper_paths))
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
