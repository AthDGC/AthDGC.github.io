#!/usr/bin/env python3
"""
COMPREHENSIVE PAPER VERIFICATION TOOL
======================================

Complete citation verification + contradiction analysis for academic papers.

Based on strategies used for Professor Lavidas's papers:
- Citation extraction and verification
- Relevance checking for paper topic
- Contradiction detection (internal and cross-paper)
- Visual marking in Word documents
- Comprehensive reporting

Author: Created for Professor Nikolaos Lavidas
Date: December 2025
"""

import os
import sys
import re
from typing import List, Dict, Tuple, Optional, Set
from dataclasses import dataclass
from datetime import datetime
from docx import Document
from docx.shared import RGBColor, Pt

# Color definitions
BOLD_GREEN = RGBColor(0, 200, 0)   # Errors
ORANGE = RGBColor(255, 165, 0)      # Warnings
RED = RGBColor(255, 0, 0)           # Critical issues
BLUE = RGBColor(0, 100, 255)        # Info


@dataclass
class Citation:
    """Represents a single citation found in the paper."""
    text: str                    # Full citation text
    author: str                  # Primary author(s)
    year: str                    # Publication year
    pages: Optional[str]         # Page numbers if present
    paragraph_idx: int           # Location in document
    context: str                 # Surrounding text
    
    def __hash__(self):
        return hash((self.author, self.year, self.pages))
    
    def __eq__(self, other):
        return (self.author == other.author and 
                self.year == other.year and 
                self.pages == other.pages)


@dataclass
class Contradiction:
    """Represents a detected contradiction."""
    type: str                    # Type of contradiction
    severity: str                # 'SEVERE', 'MODERATE', 'MINOR'
    description: str             # What the contradiction is
    locations: List[int]         # Paragraph indices
    impact: str                  # Impact on paper
    fix: str                     # How to fix it


@dataclass
class VerificationResult:
    """Complete verification results for a paper."""
    filename: str
    paper_topic: str
    total_citations: int
    citations: List[Citation]
    correct_citations: List[str]
    errors: List[Dict]
    warnings: List[Dict]
    contradictions: List[Contradiction]
    statistics: Dict


class CitationExtractor:
    """Extracts citations from Word documents."""
    
    # Comprehensive citation patterns
    PATTERNS = [
        # (Author Year: pages)
        r'\(([A-ZΑ-Ω][a-zα-ωÀ-ÿά-ώ]+(?:\s+(?:&|and|et)\s+[A-ZΑ-Ω][a-zα-ωÀ-ÿά-ώ]+)*(?:\s+et al\.)?)\s+(\d{4}[a-z]?)(?::\s*(\d+(?:[-–]\d+)?(?:,\s*\d+(?:[-–]\d+)?)*))?\)',
        # Author & Author (Year, pp. XX-XX)
        r'([A-ZΑ-Ω][a-zα-ωÀ-ÿά-ώ]+(?:\s+&\s+[A-ZΑ-Ω][a-zα-ωÀ-ÿά-ώ]+)+)\s+\((\d{4}),?\s+pp?\.\s+(\d+(?:[-–]\d+)?)\)',
        # Author (Year, pp. XX-XX)
        r'([A-ZΑ-Ω][a-zα-ωÀ-ÿά-ώ]+)\s+\((\d{4}),?\s+pp?\.\s+(\d+(?:[-–]\d+)?)\)',
        # Author et al. (Year)
        r'([A-ZΑ-Ω][a-zα-ωÀ-ÿά-ώ]+)\s+et al\.\s+\((\d{4})\)',
    ]
    
    @staticmethod
    def extract_from_document(doc_path: str) -> Tuple[List[Citation], List[Dict]]:
        """
        Extract all citations from a Word document.
        
        Returns:
            Tuple of (citations_list, paragraphs_list)
        """
        try:
            doc = Document(doc_path)
        except Exception as e:
            print(f"❌ Error opening document: {e}")
            return [], []
        
        all_citations = []
        all_paragraphs = []
        
        for para_idx, para in enumerate(doc.paragraphs):
            if not para.text.strip():
                continue
                
            all_paragraphs.append({
                'idx': para_idx,
                'text': para.text
            })
            
            # Try all patterns
            for pattern in CitationExtractor.PATTERNS:
                for match in re.finditer(pattern, para.text):
                    # Get context
                    cit_pos = match.start()
                    context_start = max(0, cit_pos - 100)
                    context_end = min(len(para.text), cit_pos + len(match.group(0)) + 100)
                    context = para.text[context_start:context_end].replace('\n', ' ')
                    
                    # Extract components
                    groups = match.groups()
                    author = groups[0] if groups[0] else "Unknown"
                    year = groups[1] if len(groups) > 1 else "Unknown"
                    pages = groups[2] if len(groups) > 2 and groups[2] else None
                    
                    citation = Citation(
                        text=match.group(0),
                        author=author,
                        year=year,
                        pages=pages,
                        paragraph_idx=para_idx,
                        context=context
                    )
                    
                    all_citations.append(citation)
        
        return all_citations, all_paragraphs


class ContradictionDetector:
    """Detects contradictions within papers and across papers."""
    
    @staticmethod
    def check_temporal_contradictions(citations: List[Citation], 
                                     paragraphs: List[Dict]) -> List[Contradiction]:
        """
        Detect temporal contradictions (e.g., citing non-existent years).
        
        Based on Lavidas papers: Found "Lavidas 2009" cited but book is from 2022
        """
        contradictions = []
        
        # Group citations by author
        author_years = {}
        for cit in citations:
            author = cit.author.split('&')[0].strip()  # Get first author
            if author not in author_years:
                author_years[author] = set()
            author_years[author].add((cit.year, cit.paragraph_idx))
        
        # Check for suspicious patterns
        for author, years_locs in author_years.items():
            years = [y[0] for y in years_locs]
            
            # Check if years span suspiciously
            if len(years) > 1:
                year_ints = [int(y[:4]) for y in years if y[:4].isdigit()]
                if year_ints:
                    year_range = max(year_ints) - min(year_ints)
                    
                    # Flag if same author cited across >15 years (might be error)
                    if year_range > 15:
                        locs = [loc for _, loc in years_locs]
                        contradictions.append(Contradiction(
                            type="TEMPORAL_RANGE",
                            severity="MINOR",
                            description=f"{author} cited across {year_range} year span ({min(year_ints)}-{max(year_ints)})",
                            locations=locs,
                            impact="Verify these are all correct - unusual range for single author",
                            fix=f"Check if all {author} citations are accurate"
                        ))
        
        return contradictions
    
    @staticmethod
    def check_attribution_contradictions(citations: List[Citation]) -> List[Contradiction]:
        """
        Detect attribution contradictions (same work cited differently).
        
        Based on Paper 2: "Haug & Jøhndal 2008" sometimes cited as just "Jøhndal 2008"
        """
        contradictions = []
        
        # Group by year and look for overlapping authors
        year_citations = {}
        for cit in citations:
            if cit.year not in year_citations:
                year_citations[cit.year] = []
            year_citations[cit.year].append(cit)
        
        # Check each year for potential duplicates
        for year, cits in year_citations.items():
            # Get all author combinations for this year
            authors_in_year = {}
            for cit in cits:
                author_key = cit.author.lower()
                if author_key not in authors_in_year:
                    authors_in_year[author_key] = []
                authors_in_year[author_key].append(cit)
            
            # Check if any author appears alone AND in multi-author citation
            author_surnames = {}
            for author_key, cit_list in authors_in_year.items():
                # Extract surnames
                surnames = set()
                for part in author_key.split('&'):
                    part = part.strip().replace('et al.', '').strip()
                    if part:
                        surname = part.split()[0]  # First word
                        surnames.add(surname)
                
                for surname in surnames:
                    if surname not in author_surnames:
                        author_surnames[surname] = []
                    author_surnames[surname].extend(cit_list)
            
            # Find surnames that appear in multiple citation forms
            for surname, surname_cits in author_surnames.items():
                unique_forms = set([c.author for c in surname_cits])
                if len(unique_forms) > 1:
                    # Check if one is subset of another (e.g., "Crane" vs "Bamman & Crane")
                    forms_list = list(unique_forms)
                    for i, form1 in enumerate(forms_list):
                        for form2 in forms_list[i+1:]:
                            if surname in form1.lower() and surname in form2.lower():
                                # Potential duplicate
                                locs = [c.paragraph_idx for c in surname_cits]
                                contradictions.append(Contradiction(
                                    type="ATTRIBUTION_INCONSISTENCY",
                                    severity="MODERATE",
                                    description=f"Work cited as both '{form1}' and '{form2}' in {year}",
                                    locations=locs,
                                    impact="Creates ambiguity - appears to be two different sources",
                                    fix=f"Standardize to full author list for all citations"
                                ))
                                break
        
        return contradictions
    
    @staticmethod
    def check_thematic_contradictions(paper_topic: str, 
                                     citations: List[Citation],
                                     reference_section: List[str]) -> List[Contradiction]:
        """
        Check if references match paper topic.
        
        Based on Paper 1: "Urban Education" in Greek linguistics paper
        """
        contradictions = []
        
        # Define topic keywords for common fields
        topic_keywords = {
            'linguistics': ['language', 'syntax', 'grammar', 'morphology', 'corpus', 'linguistic'],
            'greek': ['greek', 'byzantine', 'classical', 'koine', 'hellenistic'],
            'translation': ['translation', 'translat', 'bilingual'],
            'corpus': ['corpus', 'corpora', 'annotation', 'treebank'],
        }
        
        # Extract paper topic keywords
        paper_keywords = set()
        topic_lower = paper_topic.lower()
        for field, keywords in topic_keywords.items():
            if any(kw in topic_lower for kw in keywords):
                paper_keywords.update(keywords)
        
        # Check reference section for mismatched topics
        obviously_wrong = [
            ('urban education', 'education theory'),
            ('business', 'business/management'),
            ('sustainability', 'environmental science'),
            ('green growth', 'economics'),
            ('chemistry', 'chemistry'),
            ('lactic acid', 'chemistry'),
            ('copolymer', 'materials science'),
            ('machine learning', 'computer science'),  # unless relevant
            ('data mining', 'data science'),  # unless relevant
        ]
        
        for ref_text in reference_section:
            ref_lower = ref_text.lower()
            for wrong_term, field in obviously_wrong:
                if wrong_term in ref_lower:
                    # Check if this is obviously irrelevant
                    if not any(kw in ref_lower for kw in paper_keywords):
                        contradictions.append(Contradiction(
                            type="THEMATIC_MISMATCH",
                            severity="SEVERE",
                            description=f"Reference about {field} in paper about {paper_topic}",
                            locations=[],
                            impact="Reference completely irrelevant to paper topic",
                            fix=f"Remove or replace with relevant work"
                        ))
        
        return contradictions


class PaperVerifier:
    """Main verification engine."""
    
    def __init__(self):
        self.extractor = CitationExtractor()
        self.detector = ContradictionDetector()
    
    def verify_paper(self, doc_path: str, paper_topic: str) -> VerificationResult:
        """
        Complete verification of a paper.
        
        Args:
            doc_path: Path to Word document
            paper_topic: Brief description of paper topic
            
        Returns:
            VerificationResult object
        """
        print(f"\n{'='*80}")
        print(f"VERIFYING: {os.path.basename(doc_path)}")
        print(f"Topic: {paper_topic}")
        print(f"{'='*80}\n")
        
        # Extract citations
        print("📋 Step 1: Extracting citations...")
        citations, paragraphs = self.extractor.extract_from_document(doc_path)
        unique_citations = list(set(citations))
        
        print(f"   Found: {len(citations)} total citations")
        print(f"   Unique: {len(unique_citations)} unique citations\n")
        
        # Detect contradictions
        print("🔍 Step 2: Detecting contradictions...")
        
        temporal_contradictions = self.detector.check_temporal_contradictions(
            citations, paragraphs
        )
        print(f"   Temporal: {len(temporal_contradictions)} found")
        
        attribution_contradictions = self.detector.check_attribution_contradictions(
            citations
        )
        print(f"   Attribution: {len(attribution_contradictions)} found")
        
        # Get reference section
        ref_section = self._extract_reference_section(paragraphs)
        thematic_contradictions = self.detector.check_thematic_contradictions(
            paper_topic, citations, ref_section
        )
        print(f"   Thematic: {len(thematic_contradictions)} found\n")
        
        all_contradictions = (temporal_contradictions + 
                            attribution_contradictions + 
                            thematic_contradictions)
        
        # Compile statistics
        statistics = {
            'total_citations': len(citations),
            'unique_citations': len(unique_citations),
            'contradictions': {
                'severe': len([c for c in all_contradictions if c.severity == 'SEVERE']),
                'moderate': len([c for c in all_contradictions if c.severity == 'MODERATE']),
                'minor': len([c for c in all_contradictions if c.severity == 'MINOR']),
            }
        }
        
        result = VerificationResult(
            filename=os.path.basename(doc_path),
            paper_topic=paper_topic,
            total_citations=len(citations),
            citations=unique_citations,
            correct_citations=[],  # To be filled by user knowledge
            errors=[],  # To be filled by user knowledge
            warnings=[],  # To be filled by user knowledge
            contradictions=all_contradictions,
            statistics=statistics
        )
        
        return result
    
    def _extract_reference_section(self, paragraphs: List[Dict]) -> List[str]:
        """Extract reference section from paragraphs."""
        ref_section = []
        in_references = False
        
        for para in paragraphs:
            text = para['text'].strip()
            
            # Check if entering references
            if re.match(r'^(REFERENCES|Bibliography|Works Cited)', text, re.IGNORECASE):
                in_references = True
                continue
            
            if in_references:
                if text:  # Non-empty
                    ref_section.append(text)
        
        return ref_section
    
    def mark_document(self, doc_path: str, output_path: str, 
                     errors: List[Dict], warnings: List[Dict],
                     contradictions: List[Contradiction]) -> None:
        """
        Mark errors and warnings in document.
        
        Args:
            doc_path: Input document
            output_path: Output document with markings
            errors: List of errors to mark in GREEN
            warnings: List of warnings to mark in ORANGE
            contradictions: List of contradictions to mark
        """
        print(f"\n📝 Marking document...")
        
        doc = Document(doc_path)
        
        # Mark errors (from contradiction detection)
        for contradiction in contradictions:
            for para_idx in contradiction.locations:
                if para_idx < len(doc.paragraphs):
                    para = doc.paragraphs[para_idx]
                    
                    color = BOLD_GREEN if contradiction.severity == 'SEVERE' else ORANGE
                    
                    for run in para.runs:
                        if run.text.strip():
                            run.font.color.rgb = color
                            run.bold = True
        
        # Add corrections section
        doc.add_page_break()
        
        heading = doc.add_paragraph()
        run = heading.add_run('VERIFICATION RESULTS')
        run.bold = True
        run.font.size = Pt(20)
        run.font.color.rgb = RED
        
        doc.add_paragraph()
        
        # Add contradictions
        if contradictions:
            subhead = doc.add_paragraph()
            run = subhead.add_run('CONTRADICTIONS FOUND:')
            run.bold = True
            run.font.size = Pt(14)
            
            for i, contr in enumerate(contradictions, 1):
                doc.add_paragraph()
                
                # Contradiction header
                header = doc.add_paragraph()
                severity_symbol = {'SEVERE': '🔴', 'MODERATE': '🟠', 'MINOR': '🟡'}
                run = header.add_run(f"{i}. {severity_symbol.get(contr.severity, '⚠️')} {contr.type}")
                run.bold = True
                run.font.size = Pt(12)
                
                # Details
                detail_para = doc.add_paragraph()
                detail_para.add_run(f"   Issue: {contr.description}").font.size = Pt(10)
                
                impact_para = doc.add_paragraph()
                impact_para.add_run(f"   Impact: {contr.impact}").font.size = Pt(10)
                
                fix_para = doc.add_paragraph()
                run = fix_para.add_run(f"   Fix: {contr.fix}")
                run.font.size = Pt(10)
                run.font.color.rgb = BOLD_GREEN
                
                if contr.locations:
                    loc_para = doc.add_paragraph()
                    loc_para.add_run(f"   Locations: Paragraphs {', '.join(map(str, contr.locations[:10]))}").font.size = Pt(9)
        
        # Save
        doc.save(output_path)
        print(f"   ✓ Saved: {os.path.basename(output_path)}")
    
    def generate_report(self, results: List[VerificationResult], 
                       output_path: str) -> None:
        """
        Generate comprehensive report.
        
        Args:
            results: List of verification results (can verify multiple papers)
            output_path: Path for output report
        """
        print(f"\n📊 Generating report...")
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write("# COMPREHENSIVE PAPER VERIFICATION REPORT\n\n")
            f.write(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            f.write("---\n\n")
            
            for result in results:
                f.write(f"## Paper: {result.filename}\n\n")
                f.write(f"**Topic:** {result.paper_topic}\n\n")
                
                # Statistics
                f.write(f"### Statistics\n\n")
                f.write(f"- Total citations: {result.statistics['total_citations']}\n")
                f.write(f"- Unique citations: {result.statistics['unique_citations']}\n")
                f.write(f"- Contradictions:\n")
                f.write(f"  - 🔴 Severe: {result.statistics['contradictions']['severe']}\n")
                f.write(f"  - 🟠 Moderate: {result.statistics['contradictions']['moderate']}\n")
                f.write(f"  - 🟡 Minor: {result.statistics['contradictions']['minor']}\n")
                f.write("\n")
                
                # Contradictions
                if result.contradictions:
                    f.write(f"### Contradictions Found\n\n")
                    
                    for i, contr in enumerate(result.contradictions, 1):
                        severity_symbol = {'SEVERE': '🔴', 'MODERATE': '🟠', 'MINOR': '🟡'}
                        f.write(f"**{i}. {severity_symbol.get(contr.severity, '⚠️')} {contr.type}**\n\n")
                        f.write(f"- **Issue:** {contr.description}\n")
                        f.write(f"- **Impact:** {contr.impact}\n")
                        f.write(f"- **Fix:** {contr.fix}\n")
                        if contr.locations:
                            f.write(f"- **Locations:** Paragraphs {', '.join(map(str, contr.locations[:10]))}\n")
                        f.write("\n")
                else:
                    f.write("✅ No contradictions detected.\n\n")
                
                # Citations list
                f.write(f"### All Citations\n\n")
                unique_cits = sorted(set([(c.author, c.year) for c in result.citations]))
                for author, year in unique_cits:
                    f.write(f"- {author} ({year})\n")
                
                f.write("\n---\n\n")
        
        print(f"   ✓ Report saved: {os.path.basename(output_path)}")


def main():
    """Main entry point."""
    print("=" * 80)
    print("COMPREHENSIVE PAPER VERIFICATION TOOL")
    print("Citation Verification + Contradiction Analysis")
    print("=" * 80)
    
    # This is a library - use from other scripts
    print("\n✓ Tool loaded successfully")
    print("\nUsage:")
    print("  from paper_verifier import PaperVerifier")
    print("  verifier = PaperVerifier()")
    print("  result = verifier.verify_paper('paper.docx', 'Topic description')")
    

if __name__ == "__main__":
    main()
