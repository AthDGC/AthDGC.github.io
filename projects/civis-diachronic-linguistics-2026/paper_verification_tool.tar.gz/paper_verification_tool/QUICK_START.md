# 🚀 QUICK START GUIDE
## Get Verifying in 5 Minutes!

---

## Step 1: Extract the Tool (1 minute)

```bash
# Extract the downloaded file
tar -xzf paper_verification_tool.tar.gz

# Navigate to the tool
cd paper_verification_tool
```

---

## Step 2: Install Dependencies (1 minute)

```bash
# Install python-docx
pip install python-docx

# Or if you use pip3:
pip3 install python-docx
```

---

## Step 3: Test Installation (1 minute)

```bash
# Run the test script
python3 test_installation.py

# You should see: "🎉 All tests passed!"
```

---

## Step 4: Verify Your First Paper (2 minutes)

```bash
# Option A: Interactive mode (easiest)
python3 verify_paper.py
# Then follow the prompts

# Option B: Direct mode (fastest)
python3 verify_paper.py /path/to/your/paper.docx
# Enter your paper's topic when prompted
```

---

## Step 5: Review Results

The tool creates two files:

1. **`your_paper_VERIFIED.docx`**
   - Open this in Word
   - Look for **BOLD GREEN** text (errors)
   - Look for **ORANGE** text (warnings)
   - Read corrections page at end

2. **`your_paper_REPORT.md`**
   - Open in any text editor
   - See all contradictions listed
   - Read recommended fixes
   - Check statistics

---

## 🎯 What to Fix

### 🔴 Severe Issues (Fix First!)
- Wrong publication years
- References unrelated to your topic
- Major citation errors

### 🟠 Moderate Issues (Fix Next)
- Inconsistent co-author citations
- Wrong author names
- Attribution problems

### 🟡 Minor Issues (Review)
- Unusual citation patterns
- Things to double-check

---

## 💡 Example Session

```bash
$ python3 verify_paper.py

COMPREHENSIVE PAPER VERIFICATION TOOL
================================================================================

🔍 VERIFICATION MODE:
   1. Single paper
   2. Multiple papers
   3. Exit

Select mode (1/2/3): 1

📄 Enter paper information:

Paper path (.docx file): /home/user/my_paper.docx

📝 Briefly describe your paper's topic:
Topic: Byzantine Greek linguistics

📁 Output directory: [press Enter]

================================================================================
STARTING VERIFICATION
================================================================================

📋 Step 1: Extracting citations...
   Found: 45 total citations
   Unique: 32 unique citations

🔍 Step 2: Detecting contradictions...
   Temporal: 1 found
   Attribution: 3 found
   Thematic: 0 found

📝 Marking document...
   ✓ Saved: my_paper_VERIFIED.docx

📊 Generating report...
   ✓ Report saved: my_paper_REPORT.md

================================================================================
✅ VERIFICATION COMPLETE!
================================================================================

📄 Output files:
   1. Marked document: my_paper_VERIFIED.docx
   2. Report: my_paper_REPORT.md

   Location: /home/user/
```

---

## 📖 Next Steps

1. ✅ Read README.md (overview)
2. ✅ Read USER_GUIDE.md (detailed instructions & examples)
3. ✅ Run on your papers
4. ✅ Use before every submission!

---

## 🆘 Quick Troubleshooting

### Problem: "Package not found"
**Solution:**
```bash
pip install python-docx
```

### Problem: "No citations found"
**Solution:** Check if citations use format like:
- (Author 2020)
- Author (2020)
- (Author & Author 2020)

### Problem: "File not found"
**Solution:** Use full path:
```bash
python3 verify_paper.py /full/path/to/paper.docx
```

---

## ✨ Pro Tips

1. **Save a backup** before running tool
2. **Close the Word document** before running tool
3. **Run after major changes** to catch new errors
4. **Use for all papers** - consistency across work
5. **Check both marked doc AND report** - complementary info

---

## 📞 Need More Help?

- **Full guide:** USER_GUIDE.md
- **Examples:** See USER_GUIDE.md (your actual papers)
- **Test:** `python3 test_installation.py`

---

**That's it! You're ready to verify papers! 🎓✨**
